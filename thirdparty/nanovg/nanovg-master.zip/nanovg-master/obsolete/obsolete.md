The files in this folder will be removed in near future.

- nanovg_gl2.h and nanovg_gl3.h
  - These were the first GL2 and GL3 backends
  - an optimized version of the gl3 backed was build and later GL2 support was added to it
  - the new combined backend has superseded the individual backends