#! /bin/sh 

m4 qwtdoc.m4 $1 
