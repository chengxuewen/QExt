var class_qwt_analog_clock =
[
    [ "Hand", "class_qwt_analog_clock.html#acd8f7e963ae073120684de46821f2cfe", [
      [ "SecondHand", "class_qwt_analog_clock.html#acd8f7e963ae073120684de46821f2cfea2d9426a775588d3afb667ca8e9393c8d", null ],
      [ "MinuteHand", "class_qwt_analog_clock.html#acd8f7e963ae073120684de46821f2cfea024c7bee0110b50aad1bfffe6f468744", null ],
      [ "HourHand", "class_qwt_analog_clock.html#acd8f7e963ae073120684de46821f2cfea1e8f73f647c5a95ca062a8d63376982a", null ],
      [ "NHands", "class_qwt_analog_clock.html#acd8f7e963ae073120684de46821f2cfea004c9f49b4271e02f350bccd21235ecd", null ]
    ] ],
    [ "QwtAnalogClock", "class_qwt_analog_clock.html#af52a1110f1db89c162f49a23772745b9", null ],
    [ "~QwtAnalogClock", "class_qwt_analog_clock.html#a3abdcecf88e3d3510d94e96e7e9e74ee", null ],
    [ "drawHand", "class_qwt_analog_clock.html#a989638ce2b03e02fc0c549c16733f5ad", null ],
    [ "drawNeedle", "class_qwt_analog_clock.html#af3ec354864af5b4cd1295a4746960142", null ],
    [ "hand", "class_qwt_analog_clock.html#abb93bf8255bc00ef160165385bb6adce", null ],
    [ "hand", "class_qwt_analog_clock.html#a4231bc54b5bd8a7530f03515aeec7689", null ],
    [ "setCurrentTime", "class_qwt_analog_clock.html#a1972a54ce59155ec7435103f11a775a7", null ],
    [ "setHand", "class_qwt_analog_clock.html#a643101aafbe7a6fc91cb550203a7d3ee", null ],
    [ "setTime", "class_qwt_analog_clock.html#aa99a628b290789583052bcec9163d95c", null ]
];