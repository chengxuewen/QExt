var class_qwt_o_h_l_c_sample =
[
    [ "QwtOHLCSample", "class_qwt_o_h_l_c_sample.html#ad4056581f619e0a36d854fc5bb4341ef", null ],
    [ "boundingInterval", "class_qwt_o_h_l_c_sample.html#a8e282be32be601a1ed3c725cbe614fa9", null ],
    [ "isValid", "class_qwt_o_h_l_c_sample.html#a5656375ea78ab080d53114ab80aa3934", null ],
    [ "close", "class_qwt_o_h_l_c_sample.html#a7627b9a618065a82e96e651406f4fac4", null ],
    [ "high", "class_qwt_o_h_l_c_sample.html#a4b23c1c6250364d4c58b6fc23ac1cdff", null ],
    [ "low", "class_qwt_o_h_l_c_sample.html#aedac8489a18dfae092c010360c53ad7d", null ],
    [ "open", "class_qwt_o_h_l_c_sample.html#a71b133fe8f7676b2ff7b17e39d669f95", null ],
    [ "time", "class_qwt_o_h_l_c_sample.html#a7d457c0a7d71f90539bf6233a19c1df4", null ]
];