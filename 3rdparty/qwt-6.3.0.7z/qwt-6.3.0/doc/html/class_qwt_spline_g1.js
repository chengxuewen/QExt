var class_qwt_spline_g1 =
[
    [ "QwtSplineG1", "class_qwt_spline_g1.html#aba43f62873a477b2733d4ced610d038d", null ],
    [ "~QwtSplineG1", "class_qwt_spline_g1.html#a441218078365cb31416fd28501eefa2f", null ]
];