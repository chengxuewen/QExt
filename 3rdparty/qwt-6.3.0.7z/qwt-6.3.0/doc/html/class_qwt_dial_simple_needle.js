var class_qwt_dial_simple_needle =
[
    [ "Style", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584", [
      [ "Arrow", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584a27ace220f0a5c6abd061c85bbdc9a663", null ],
      [ "Ray", "class_qwt_dial_simple_needle.html#ad28821489e04f1fd942e5bebc8a60584a580980e68ef26fc7d35962cf6f12a4b2", null ]
    ] ],
    [ "QwtDialSimpleNeedle", "class_qwt_dial_simple_needle.html#a5f16b9298ecd293360a3ccf91d3dbfbb", null ],
    [ "drawNeedle", "class_qwt_dial_simple_needle.html#a3c7765638bd3aa59d22f0ff55175a40f", null ],
    [ "setWidth", "class_qwt_dial_simple_needle.html#ad7672543371e38c864e44d9240271c22", null ],
    [ "width", "class_qwt_dial_simple_needle.html#a932eb587ddb1b091ecb6ced52b4bdbc5", null ]
];