***************************
Working with ROS 1 Messages
***************************

Writer Example
--------------
.. literalinclude:: ../examples/ros1/writer.py

Reader Example
--------------
.. literalinclude:: ../examples/ros1/reader.py
