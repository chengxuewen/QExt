package mcap

// Version of the MCAP library.
var Version = "v1.6.0"
