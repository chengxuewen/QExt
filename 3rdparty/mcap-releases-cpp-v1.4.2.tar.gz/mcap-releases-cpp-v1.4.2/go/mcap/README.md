## mcap

> Note: This library is experimental and will change without warning until
> finalization of the spec.

An experimental library for writing and reading MCAP files in go.

### API reference

API documentation can be found [here](https://pkg.go.dev/github.com/foxglove/mcap/go/mcap).
