## ros utilities

MCAP conversion utilities for ROS bags.
