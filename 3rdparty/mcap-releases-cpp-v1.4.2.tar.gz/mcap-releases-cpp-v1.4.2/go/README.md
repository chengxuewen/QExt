## MCAP go libraries

[mcap]: ./mcap
[mcap cli]: ./cli/mcap

- [Library for parsing MCAP files][mcap]
- [Command line tool for format demonstration][mcap cli]
