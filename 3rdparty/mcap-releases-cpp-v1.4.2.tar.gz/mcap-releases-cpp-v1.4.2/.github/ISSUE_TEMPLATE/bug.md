---
name: "🐞 Bug report"
about: Report broken functionality or incorrect documentation
labels: "bug"
---

**Description**

- Version:
- Platform:

**Steps To Reproduce**

<!--- Include the minimum possible code or example data to reproduce the problem. -->

**Expected Behavior**
