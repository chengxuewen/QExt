#define MCAP_IMPLEMENTATION
#include <mcap/reader.hpp>
#include <mcap/writer.hpp>

// hdoc generates docs using compile_commands.json, so we need a translation unit (even if empty)
// from which to generate docs.
