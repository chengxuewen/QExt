static int /*%return name%*/(lua_State *L)
{
/*% return overloads()%*/

	return luaL_error(L, "No valid overload found.");
}

