static int /*%return name%*/(lua_State *L)
{
	return luaL_error(L, "Cannot extend this class.");
}

